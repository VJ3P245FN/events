<?php defined( 'LS_ROOT_FILE' ) || exit; ?>
<script type="text/html" id="tmpl-slider-group-placeholder">
<div class="ls-item ls-scale0">
	<div class="ls-preview">
		<div class="no-preview">
			<?= __('No Preview', 'LayerSlider') ?>
		</div>
	</div>
</div>
</script>